# Configurações básicas
