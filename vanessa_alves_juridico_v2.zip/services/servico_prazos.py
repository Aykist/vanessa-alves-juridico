# Lógica de prazos
