# Lógica de clientes
